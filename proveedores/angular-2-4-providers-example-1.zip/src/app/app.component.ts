import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
          <any-animal></any-animal>
          <lion></lion> 
		  <cow></cow>
  `
})
export class AppComponent {
}
 
