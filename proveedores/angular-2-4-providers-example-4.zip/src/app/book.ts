export class Book {
	constructor(public name: string, public category: string){}
}